# @trovix/license-contract

Token format, request/response schemas, and the client-side verifier shared by the Trovix desktop app and the Trovix license service. This is the one thing both sides must never disagree about, so it lives in its own versioned package rather than being duplicated.

Nothing in this package is secret: it ships the public half of the signing keys only, plus pure functions and Zod schemas. The private signing key never leaves the service (AWS KMS in production).

## What's in it

- **Token claims and request/response schemas** (`schemas.ts`) — Zod schemas for `/v1/activate`, `/v1/validate`, `/v1/deactivate`, and the signed license token's claims.
- **`verifyLicenseToken()`** (`verify.ts`) — the client-side verifier: pinned algorithm (no `alg: none`), issuer/audience/subject checks, nonce matching, expiry, and a high-water-mark check so a stale or clock-rolled-back token can never look newer than one already accepted.
- **Public key registry** (`keys.ts`) — the service's current and previous signing keys, by `kid`, so a key rotation stays verifiable during the overlap window.
- **Activation key format** (`activationKey.ts`) — the Crockford base32 + checksum format, shared so the app can reject a typo offline before ever calling the service.
- **Constants** (`constants.ts`) — token issuer/audience, default trial length, token TTL, clock skew tolerance.
- **`test-vectors.json`** — fixed sample tokens and expected verdicts, used by both the service's signer tests and this package's own verifier tests, so the two repos are proven to agree.

## Install

```bash
npm install @trovix/license-contract
```

## Usage

```ts
import { verifyLicenseToken, PUBLIC_KEYS } from '@trovix/license-contract';

const result = verifyLicenseToken(token, {
  publicKeys: PUBLIC_KEYS,
  expectedDeviceId,
  expectedNonce,
  nowMs: Date.now(),
});

if (result.ok) {
  // result.claims is the verified TokenClaims
} else {
  // result.reason — never throws; treat any failure as "offline", not a revocation
}
```

## Versioning

Semantic versioning, with the token's own `v` claim tracking this package's major version. A breaking change to the claims is a new major version; the service issues the old and new claim shapes in parallel until old app builds age out. Never remove or repurpose an existing field — additive only.

## Source

Developed inside [`trovix-license-service`](https://github.com/itsmohitkr/trovix-license-service) (private) at `shared/contract`. This package itself is published publicly since it contains no secrets and both consuming apps need to install it without private-registry authentication in CI.
